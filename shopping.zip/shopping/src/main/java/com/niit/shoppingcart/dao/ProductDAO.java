package com.niit.shoppingcart.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.niit.shoppingcart.model.Product;
@Component
public interface ProductDAO 
{
	public boolean addProduct(Product product);
	public boolean updateProduct(Product product);
	public List getAllProducts();
	public Product getSingleProduct(int id);
	public void deleteProduct(int id);
}
