package com.niit.shoppingcart.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity  
@Table
@Component
public class Product implements Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="productId")
	int productId;
	@NotNull
	@Size(min=2,max=30,message="*Enter Product Name")
	@Column(name="productName")
	String productName;
	@NotNull
	@Min(5)
	@Column(name="productPrice")
	int productPrice;
	@NotNull
	@Size(min=2,max=30,message="*Enter Product Description")
	@Column(name="productDesc")
	String productDesc;
	@NotNull
	@Size(min=2,max=30,message="*Enter Product chairStyle")
	@Column(name="productStyle")
	String productStyle;
	@NotNull
	@Size(min=2,max=30,message="*Enter Product Warranty")
	@Column(name="warranty")
	String warranty;
	@NotNull
	@Size(min=2,max=30,message="*Enter Product PrimaryMeterial")
	@Column(name="primaryMeterial")
	String primaryMeterial;
	@NotNull
	@Size(min=2,max=30,message="*Enter Product Capacity")
	@Column(name="capacity")
	String capacity;
	@Column(name="image",columnDefinition="varchar(255)")
	@Size(min=3,message="Please Select the Image")
	private	String image;
	@JsonIgnore
	transient private MultipartFile img;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public String getProductStyle() {
		return productStyle;
	}
	public void setProductStyle(String productStyle) {
		this.productStyle = productStyle;
	}
	public String getWarranty() {
		return warranty;
	}
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	public String getPrimaryMeterial() {
		return primaryMeterial;
	}
	public void setPrimaryMeterial(String primaryMeterial) {
		this.primaryMeterial = primaryMeterial;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public MultipartFile getImg() {
		return img;
	}
	public void setImg(MultipartFile img) {
		this.img = img;
	}
	 	
	

}
