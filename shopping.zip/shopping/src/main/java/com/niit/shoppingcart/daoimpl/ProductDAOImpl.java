package com.niit.shoppingcart.daoimpl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;
@Repository("productDAO")
@Transactional
public class ProductDAOImpl implements ProductDAO
{
	@Autowired
	private SessionFactory sessionFactory;
	public SessionFactory getSessionFactory() 
	{
		return sessionFactory;
	}
	public void setSessionFactory(SessionFactory sessionFactory) 
	{
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public boolean addProduct(Product product) 
	{
		try 
	    {
		sessionFactory.getCurrentSession().saveOrUpdate(product);
		return true;
	    }
		catch (HibernateException e) 
	     {
		e.printStackTrace();
		return false;
	     }		
	}
	
	@Transactional
	public boolean updateProduct(Product product) 
	 {
		try 
	    {
		sessionFactory.getCurrentSession().update(product);
		return true;
	    } 
	    catch (HibernateException e) 
	     {
		e.printStackTrace();
		return false;
	     }		
	 }
	@Transactional
	public List getAllProducts()
	{
	Session session=sessionFactory.openSession();
	org.hibernate.Transaction tx=session.beginTransaction();
	List blist=session.createQuery("from Product").list();
	tx.commit();
	return blist;
}
	@Transactional
	public Product getSingleProduct(int id)
		{
		Session session=sessionFactory.openSession();
		Product product=(Product)session.load(Product.class, id);
		return product;
	}

	public void deleteProduct(int id)
	{
		Session session=sessionFactory.openSession();
		org.hibernate.Transaction tx=session.beginTransaction();
		Product product=(Product)session.load(Product.class, id);
		session.delete(product);
		tx.commit();	
		session.close();
				
	}

}
