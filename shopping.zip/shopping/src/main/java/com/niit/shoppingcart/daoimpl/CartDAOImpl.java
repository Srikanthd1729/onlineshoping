package com.niit.shoppingcart.daoimpl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.model.CartItem;

@Repository("cartDAO")
public class CartDAOImpl implements CartDAO
{
	@Autowired
	private SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public boolean add(CartItem item) 
	{
		try 
		{
			sessionFactory.getCurrentSession().saveOrUpdate(item);
			return true;
		} 
		catch (HibernateException e) 
		{
			e.printStackTrace();
			return false;
		}
	}

	@Transactional
	public CartItem get(int id)
	{
		Session session = sessionFactory.getCurrentSession();
		return (CartItem) session.get(CartItem.class, id);		
	}
	@Transactional
	public List getAllItems()
	{
		Session session =sessionFactory.openSession();
        List blist1 = session.createQuery("from CartItem").list();
        return blist1;
	
	}
	@Transactional
	public void remove(int id)
	{
		Session session = sessionFactory.openSession();
		org.hibernate.Transaction tx=session.beginTransaction();
		CartItem chartItem=(CartItem)session.load(CartItem.class, id);
		session.delete(chartItem);	
		tx.commit();
		session.close();
				
	}
	public void removeAll() 
	{
		List<CartItem> cartItems = getAllItems();
		for(CartItem item: cartItems) 
		{
			remove(item.cartItemId);
		}
		
	}
//	@Transactional
//	public void update(int cartItemId,int quantity) 
//	{
//		logger.debug("Starting of the method update");
//		Session session=sessionFactory.openSession();
//		org.hibernate.Transaction tx=session.beginTransaction();
//		CartItem cartItem=(CartItem)session.load(CartItem.class, cartItemId);
//	    session.saveOrUpdate(cartItem);
//		tx.commit();
//		logger.debug("End of the method update");
//	}
	
	


}
